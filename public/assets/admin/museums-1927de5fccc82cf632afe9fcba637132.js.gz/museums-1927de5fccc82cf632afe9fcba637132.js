(function() {
  $(function() {
    return $("nav.pagination > ul").addClass("pagination");
  });

}).call(this);
